Resources used:
* https://stackoverflow.com/questions/60339049/weekday-name-from-a-pandas-dataframe-date-object
* https://www.geeksforgeeks.org/different-ways-to-iterate-over-rows-in-pandas-dataframe/
* https://realpython.com/python-keyerror/
* https://www.geeksforgeeks.org/how-to-sort-grouped-pandas-dataframe-by-group-size/
* https://www.codegrepper.com/code-examples/python/how+to+convert+month+number+to+month+name+in+python

